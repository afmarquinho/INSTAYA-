exports.dbConfig = {
  server: 'mysql.jusemon.com',
  database: 'delivery_taj',
  user: 'tatyajh',
  password: process.env.DB_PASSWORD,
  port: 3306
};
